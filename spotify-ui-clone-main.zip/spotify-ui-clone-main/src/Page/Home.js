import PlayListTile from "../Layout/PlayListTIle"
import './home.css'
import { useEffect } from "react";

const Home = () => {
    useEffect(() => {
        
    }, [])
    return ( 
        <div className="content">
            <PlayListTile />        
        </div> 
    );
}
 
export default Home;